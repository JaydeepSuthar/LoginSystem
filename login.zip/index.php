<?php require "header.php" ?>
<body>
    <h1 id="title">Welcome to the Login & Sign Up System Created By JDS @ Jaydeep Suthar</h1>
    <h2 id="title">Source Code : Available Soon</h2>
    <ul>
        <li><a href="login.php" class="btn navbtn">Login</a></li>
        <br>
        <br>
        <li><a href="signup.php" class="btn navbtn">Sign Up</a></li>
    </ul>
</body>