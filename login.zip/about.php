<?php require "header.php" ?>
<body>
    <p>This is an Simple Login & Sign Up System created by Jaydeep Suthar.
        Thanks For Using It.
    </p>
</body>